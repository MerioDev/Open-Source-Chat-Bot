const audio = require('@replit/audio');
const source = await audio.playFile({filePath: './audio.wav'});
await source.setVolume(100);
await source.togglePlaying();
