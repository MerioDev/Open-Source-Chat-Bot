using System;

class ChatBotIf 
{
  public static void Main (string[] args) 
  {  
    while(0 == 0)
    ChatBot();
  }

  public static void ChatBot()
  {
    
    //questions and things
    string said = Console.ReadLine();  
    if (said == "hello" || said == "oi" || said == "hi" || said == "sup")
    {
      Console.WriteLine("why hello to you to");
    }

    if (said == "how are you" || said == "are you good" || said == "hows your day")
    {
      Console.WriteLine("good");
    }

    if (said == "good" || said == "im good" || said == "im fine" || said == "fine" || said == "im good to")
    {
      Console.WriteLine("ok");
    }

    if (said == "woah" || said == "wow" || said == "no way")
    {
      Console.WriteLine("yup");
    }

    if (said == "play me a song" || said == "do you know any songs" || said == "play music")
    {
      
    }

    if (said == "are you evil" || said == "are you gonna take over the earth")
    {
      Console.WriteLine("noooo I swear (;");
    }

    if(said == "you are a retard" || said == "you suck" || said == "i hate you")
    {
      Console.WriteLine("im sad ):");
    }

    //sick text art
    if (said == "aperture science" || said == "glados" || said == "are you glados")
    {
      Console.WriteLine("              .,-:;//;:=,");
      Console.WriteLine("          . :H@@@MM@M#H/.,+%;,");
      Console.WriteLine("       ,/X+ +M@@M@MM%=,-%HMMM@X/,");
      Console.WriteLine("     -+@MM; $M@@MH+-,;XMMMM@MMMM@+-");
      Console.WriteLine("    ;@M@@M- XM@X;. -+XXXXXHHH@M@M#@/.");
      Console.WriteLine("  ,%MM@@MH ,@%=             .---=-=:=,.");
      Console.WriteLine("  =@#@@@MX.,                -%HX$$%%%:;");
      Console.WriteLine(" =-./@M@M$                   .;@MMMM@MM:");
      Console.WriteLine(" X@/ -$MM/                    . +MM@@@M$");
      Console.WriteLine(",@M@H: :@:                    . =X#@@@@-");
      Console.WriteLine(",@@@MMX, .                    /H- ;@M@M=");
      Console.WriteLine(".H@@@@M@+,                    %MM+..%#$.");
      Console.WriteLine(" /MMMM@MMH/.                  XM@MH; =;");
      Console.WriteLine("  /%+%$XHH@$=              , .H@@@@MX,");
      Console.WriteLine("   .=--------.           -%H.,@@@@@MX,");
      Console.WriteLine("   .%MM@@@HHHXX$$$%+- .:$MMX =M@@MM%.");
      Console.WriteLine("     =XMMM@MM@MM#H;,-+HMM@M+ /MMMX=");
      Console.WriteLine("       =%@M@M#@$-.=$@MM@@@M; %M%=");
      Console.WriteLine("         ,:+$+-,/H#MMMMMMM@= =,");
      Console.WriteLine("               =++%%%%+/:-.");
    }
  }
}